function getView($document, view)
{
	switch(view)
	{
		case 0:
		{
			var svgTag = getElementById("X-Y-Planes");
			alert(svgTag);
		}
	}
}